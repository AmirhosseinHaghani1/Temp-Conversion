let $  = document
let title = $.title
let inputChange = $.querySelector('.inputChange');
let btnConvert = $.querySelector('.btnConvert')
let btnReset = $.querySelector('.btnReset')
let btnChange = $.querySelector('.btnChange')
let ShowResult = $.querySelector('.ShowResult')
let firstValue =  $.querySelector('.C')
let secondValue =  $.querySelector('.F')
let inputValue = inputChange.value 
let sum = 0 ; 

btnConvert.addEventListener('click'  , function(){

    if(inputChange.value === '' || isNaN(inputChange.value)){
        ShowResalt.style.color = 'red'
        ShowResalt.style.fontSize = '20px';  
        ShowResalt.style.fontFamily = 'Arial, Helvetica, sans-serif';    
        ShowResalt.innerHTML = 'Please enter a number. do not use words.'
    }
    else{
        if(firstValue.innerHTML === '°C'){
            
            sum = (inputChange.value * 1.8 ) + 32
            sum = sum.toFixed(2)
            ShowResalt.style.color = 'green'
            ShowResalt.style.fontSize = '20px';  
            ShowResalt.style.fontFamily = 'Verdana, Geneva, Tahoma, sans-serif ';    
            ShowResalt.innerHTML = inputChange.value +  ' Celsius(°C)'+ " = " + sum + ' Fahrenheit (°F)'
        }
        else{
            
            sum =  (inputChange.value - 32 ) / 1.8
            sum = sum.toFixed(2)
            ShowResalt.style.color = 'green'
            ShowResalt.style.fontSize = '20px';  
            ShowResalt.style.fontFamily = 'Verdana, Geneva, Tahoma, sans-serif ';    
            ShowResalt.innerHTML = inputChange.value + ' Fahrenheit(°F)' + " = " + sum + ' Celsius(°C)'

        }
        
    }

});


btnChange.addEventListener('click'  , function(){

if(firstValue.innerHTML === '°C'){

    firstValue.innerHTML = '°F'
    secondValue.innerHTML = '°C'
    inputChange.setAttribute('placeholder' ,'°F')
    $.title = 'Convert °F to °C '
}
else{

    firstValue.innerHTML = '°C'
    secondValue.innerHTML = '°F'
    inputChange.setAttribute('placeholder' , '°C')
    $.title = 'Convert °C to °F '
}

});


btnReset.addEventListener('click'  , function(){

     inputChange.value = ''
     ShowResalt.innerHTML = ''


});     


